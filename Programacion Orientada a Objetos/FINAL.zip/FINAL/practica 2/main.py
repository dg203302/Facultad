from docente_investigador import *
if __name__ == '__main__':
    docentenuevo=docente_investigador('jose','julian','3234242','informatica',2000,'jefe',24,23444)
    print(docentenuevo)