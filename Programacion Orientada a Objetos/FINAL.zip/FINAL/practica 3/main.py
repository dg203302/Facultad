from lista import *
if __name__=='__main__':
    lista=lista_personal()
    lista.mostrar()
    lista.insertar_en_posicion()
    lista.mostrar()
    lista.mostrar_instancias()